Redruth's Basement Software

Fountain Pen Frenzy
(c) 2001 RBS
Freeware

This font is distributed as-is, and has no warranties on it whatsoever, except that I am fairly sury it's virus-free and know that it works.  It is based on handwritten characters written with an old fountain pen, which died as the font was completed.  All keyboard characters are represented, and I was kind enough not to subject you to that wretched random rectangle for undefined characters.  I played up on the pen's poor ink flow, so if it looks like a smudge or a blot, it probably is.

Distribute this disclaimer with the font at all times.  If you include it in a disc/CD collection, leave this .ZIP file separate and intact.  All modified versions need an editor's signature in the credits of the font file itself.  Thank you.

Enjoy!

<><
T.R.